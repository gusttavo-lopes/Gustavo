class Cliente extends Pessoa{
   protected String endereco;
    public Cliente(String nome, String cpf, String email, String telefone, String endereco){
        super(nome, cpf, email, telefone);
        this.endereco= endereco;
    } 

}