class Animal extends Cliente {
    private String nomeA;
    private String sexo;
    private int idade;
    private float peso;
    
    public Animal(String nome, String cpf, String email, String telefone, String endereco, String nomeA, String sexo, int idade, float peso) {
        super(nome, cpf, email, telefone, endereco);
        this.nomeA= nomeA;
        this.sexo= sexo;
        this.idade= idade;
        this.peso= peso;
    }
}