class Passaro extends Animal{
    private String especieP;
    private int envergadura_asa;
    private boolean voa;
     public Passaro(String nome, String cpf, String email, String telefone, String endereco,String nomeA, String sexo, int idade, float peso, String especieP, int envergadura_asa, boolean voa){
        super(nome, cpf, email, telefone, endereco, nomeA, sexo, idade, peso );
        this.especieP = especieP;
        this.envergadura_asa = envergadura_asa;
        this.voa = voa;
     }
}