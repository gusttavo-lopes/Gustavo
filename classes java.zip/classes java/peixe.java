class Peixe extends Animal{
    private String especie;
    private String tipo_agua;
    private int tamanho_cm;
     public Peixe(String nome, String cpf, String email, String telefone, String endereco,String nomeA, String sexo, int idade, float peso, String especie, String tipo_agua, int tamanho_cm){
        super(nome, cpf, email, telefone, endereco, nomeA, sexo, idade, peso );
        this.especie = especie;
        this.tipo_agua = tipo_agua;
        this.tamanho_cm = tamanho_cm;
     }
}