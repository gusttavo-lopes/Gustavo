class Cachorro extends Animal{
    private String raca;
    private String porte;
    private boolean vacinado;
    public Cachorro(String nome, String cpf, String email, String telefone, String endereco, String nomeA, String sexo, int idade, float peso, String raca, String porte, boolean vacinado){
        super(nome, cpf, email, telefone, endereco, nomeA, sexo, idade, peso);
        this.raca= raca;
        this.porte= porte;
        this.vacinado= vacinado;
    
    }
 }