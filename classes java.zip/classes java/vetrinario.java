class Veterinario extends Pessoa{
    protected String crmv;
    public Veterinario(String nome, String cpf, String email, String telefone, String crmv){
        super(nome ,cpf, email, telefone);
        this.crmv= crmv;

    }
}